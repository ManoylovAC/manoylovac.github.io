
/**
 * This class represents a simple ellipse.
 *
 * The position, size and rotation attributes must not be changed directly. To
 * change any of these attributes always use the move, rotate, resize and
 * scale methods as this will ensure that ellipse intersects are calculated
 * correctly.
 *
 * Research sources:
 * Calculating intersects : https://elliotnoma.wordpress.com/2013/04/10/a-closed-form-solution-for-the-intersections-of-two-ellipses/
 *
 * Last updated: 26 Jul 2023
 *
 * @author Peter Lager (2023)
 *
 * */
class Ellipse {
    /**
     *
     * @param cx horizontal poistion of the ellipse centre
     * @param cy vertical position of the ellipse centre
     * @param xr horizontal half axis length (x radius)
     * @param yr vertical half axis length (y radius)
     * @param ang angle ellipse is rotated about [cx, cy]
     */
    constructor(cx, cy, xr, yr, ang) {
        this._strokeWeight = 1;
        this._cx = cx;
        this._cy = cy;
        this._xr = xr;
        this._yr = yr;
        this._ang = ang;
        this._calculateImplicitFormulaCoefficients();
    }
    resize(xr, yr) {
        if (Number.isFinite(xr) && xr > 0 && Number.isFinite(yr) && yr > 0) {
            this._xr = xr;
            this._yr = yr;
            this._calculateImplicitFormulaCoefficients();
        }
        return this;
    }
    scale(scale) {
        if (Number.isFinite(scale) && scale > 0) {
            this._xr *= scale;
            this._yr *= scale;
            this._calculateImplicitFormulaCoefficients();
        }
        return this;
    }
    moveTo(nx, ny) {
        if (Number.isFinite(nx) && Number.isFinite(ny)) {
            this._cx = nx;
            this._cy = ny;
            this._calculateImplicitFormulaCoefficients();
        }
        return this;
    }
    moveBy(nx, ny) {
        if (Number.isFinite(nx) && Number.isFinite(ny)) {
            this._cx += nx;
            this._cy -= ny;
            this._calculateImplicitFormulaCoefficients();
        }
        return this;
    }
    rotateTo(a) {
        if (Number.isFinite(a)) {
            this._ang = a;
            this._calculateImplicitFormulaCoefficients();
        }
        return this;
    }
    rotateBy(a) {
        if (Number.isFinite(a)) {
            this._ang += a;
            this._calculateImplicitFormulaCoefficients();
        }
        return this;
    }
    isOnPerimeter(x, y) {
        return Math.abs(this.eval(x, y)) <= this._perimeterEpsilon;
    }
    /**
     * Evaluate using the implicit formulae
     *   f(v) = a.x^2 + b.x.y + c.y^2 + d.x + e.y + f
     * As f(v) => 0 the closer [x,y] is to the circumference.
     */
    eval(x, y) {
        return this.a * (x ** 2) + this.b * x * y + this.c * (y ** 2)
            + this.d * x + this.e * y + this.f;
    }
    getPerimeterPosition(angle) {
        let ex = this._xr * Math.cos(angle);
        let ey = this._yr * Math.sin(angle);
        let cosa = Math.cos(this._ang), sina = Math.sin(this._ang);
        let x = this._cx + ex * cosa - ey * sina;
        let y = this._cy + ex * sina + ey * cosa;
        return { x: x, y: y };
    }
    /**
    * Calculate the coefficients for the implicit equation
    *  a.x^2 + b.x.y + c.y^2 + d.x + e.y + f = 0
    * by first rotating the ellipse then translating it.
    */
    _calculateImplicitFormulaCoefficients() {
        let angle = Ellipse.MODE * this._ang;
        let A = Math.cos(angle), B = Math.sin(angle);
        let cx = this._cx, cy = this._cy;
        let xr2 = this._xr ** 2, yr2 = this._yr ** 2;
        let AA = A * A / xr2 + B * B / yr2;
        let BB = -2 * A * B / xr2 + 2 * A * B / yr2;
        let CC = B * B / xr2 + A * A / yr2;
        this.a = AA;
        this.b = BB;
        this.c = CC;
        this.d = -(2 * AA * cx + BB * cy);
        this.e = -(BB * cx + 2 * CC * cy);
        this.f = AA * cx * cx + BB * cx * cy + CC * cy * cy - 1;
        // Calculate evaluation threshold
        this._perimeterEpsilon = 1 / Math.min(this._xr, this._yr);
    }
    getCoefs() {
        return new Coefficients(this.a, this.b, this.c, this.d, this.e, this.f);
    }
    /**
     * Set the rendering attributes
     * @param fc the fill color
     * @param sc the stroke color
     * @param sw the stroke weight
     * @returns this ellipse
     */
    attributes(fc, sc, sw) {
        this._fill = fc;
        this._stroke = sc;
        this._strokeWeight = sw;
        return this;
    }
    /**
     *
     * @param p the drawing context
     */
    render(p = p5.instance) {
        if (!this._fill)
            this.attributes(p.color(0, 32), p.color(0, 192), 1);
        p.push();
        p.translate(this._cx, this._cy);
        p.rotate(this._ang);
        p.fill(this._fill);
        p.stroke(this._stroke);
        p.strokeWeight(this._strokeWeight);
        p.ellipse(0, 0, 2 * this._xr, 2 * this._yr);
        p.pop();
    }
    _implicitFormula() {
        function ns(n) {
            let t = Math.abs(n).toPrecision(6);
            let s = Math.sign(n) < 0 ? "-" : "+";
            return `${s} ${t}`;
        }
        return `${ns(this.a)}.x^2 ${ns(this.b)}.x.y ${ns(this.c)}.y^2 `
            + `${ns(this.d)}.x ${ns(this.e)}.y ${ns(this.f)}`;
    }
    _desc() {
        let d = `Ellipse at [${this._cx}, ${this._cy}]  with semi axis lengths`;
        d += ` ${this._xr} & ${this._yr}  rotated ${this._ang} radians`;
        return d;
    }
    printDesc() {
        console.log(this._desc());
        return this;
    }
    printEquation() {
        console.log(this._implicitFormula());
        return this;
    }
    toString() {
        return this._desc();
    }
    static intersects(es, et) {
        const numerator = (y) => c * y ** 2 + (e) * y + (f);
        const denominator = (y) => b * y + d;
        // Get coeficients for implicit equation (IE) representing the 
        // intersection of the two ellipses, elliminating the x^2 term
        let IE = Coefficients.elliminateTerm(es.getCoefs(), et.getCoefs(), 'a');
        let b = IE.b, c = IE.c, d = IE.d, e = IE.e, f = IE.f;
        // Get the implicit coefficients for one of the two ellipses
        let S = es.getCoefs();
        let sa = S.a, sb = S.b, sc = S.c, sd = S.d, se = S.e, sf = S.f;
        // Calculate the coefficents for the quartic function of y
        let p = c * d + b * e;
        let q = d * e + b * f;
        let z4 = sa * c * c
            + sc * b * b
            - sb * b * c;
        let z3 = 2 * sa * c * e +
            +2 * sc * b * d + se * b * b
            - sd * b * c - sb * p;
        let z2 = sa * (2 * c * f + e * e)
            + sc * d * d + 2 * se * b * d + sf * b * b
            - sd * p - sb * q;
        let z1 = 2 * sa * e * f
            + se * d * d + 2 * sf * b * d
            - sd * q - sb * d * f;
        let z0 = sa * f * f
            + sf * d * d
            - sd * d * f;
        // Get the quartic function of y and solve it for all roots
        let quartic = PolyBase.getPoly([z4, z3, z2, z1, z0]);
        let roots = quartic.roots();
        // Remove duplicates and complex roots using custom EPSILON
        roots = Complex.removeDuplicates(roots, 0.0001);
        roots = Complex.filterRealRoots(roots, 0.0001);
        // For all real roots calculate the x position
        let intersects = [];
        for (let r of roots) {
            let d = denominator(r.real);
            // console.log(`denominator = ${d}`)
            if (Math.abs(d) < Ellipse.EPSILON) {
                let a = sa;
                let b = sb * r.real + sd;
                let c = sc * r.real ** 2 + se * r.real + sf;
                let qroots = PolyBase.getPoly([a, b, c]).roots();
                qroots = Complex.removeDuplicates(qroots, 0.0001);
                qroots = Complex.filterRealRoots(qroots, 0.0001);
                for (let qr of qroots)
                    intersects.push({ x: qr.real, y: r.real });
            }
            else {
                let n = numerator(r.real);
                intersects.push({ x: -n / d, y: r.real });
            }
        }
        return intersects;
    }
}
// A measure of how close the ellipses are axis aligned
Ellipse.EPSILON = 1E-10;
// Used to change the rotation angle when calculating coefficients because
// on computer moitors the rotation angle is reversed when compared to 
// paper based geometry.
Ellipse.PAPER = 1;
Ellipse.MONITOR = -1;
Ellipse.MODE = Ellipse.MONITOR;
/**
 * Small utility class to hold the coefficients of the implicit equation
 * of an ellipse and for manipulating them.
 */
class Coefficients {
    constructor(a, b, c, d, e, f) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }
    static elliminateTerm(s, t, coef) {
        let _s = s.getCoef(coef);
        let _t = t.getCoef(coef);
        if (Number.isFinite(_s) && Number.isFinite(_t)) {
            s = s.mult(_t);
            t = t.mult(_s);
            let u = s.subtract(t);
            return u;
        }
        return undefined;
    }
    copy() {
        return new Coefficients(this.a, this.b, this.c, this.d, this.e, this.f);
    }
    getCoef(coef) {
        return this[coef];
    }
    divide(n) {
        if (Number.isFinite(n))
            return new Coefficients(this.a / n, this.b / n, this.c / n, this.d / n, this.e / n, this.f / n);
        return this.copy();
    }
    mult(n) {
        if (Number.isFinite(n))
            return new Coefficients(this.a * n, this.b * n, this.c * n, this.d * n, this.e * n, this.f * n);
        return this.copy();
    }
    subtract(n) {
        if (n)
            return new Coefficients(this.a - n.a, this.b - n.b, this.c - n.c, this.d - n.d, this.e - n.e, this.f - n.f);
        return this.copy();
    }
    add(n) {
        if (n)
            return new Coefficients(this.a + n.a, this.b + n.b, this.c + n.c, this.d + n.d, this.e + n.e, this.f + n.f);
        return this.copy();
    }
    print() {
        console.log(`Coefs [ a: ${this.a}   b: ${this.b}   c: ${this.c}   d: ${this.d}   e: ${this.e}   f: ${this.f}]`);
        return this;
    }
}
