
/**
 * A complex number class including many trig functions.
 *
 * This class is immutable in that none of its methods will change the
 * real or imaginary components instead they return new complex objects.
 *
 * Although the user can access the class attributes directly it is not
 * recommended as it can lead to unpredictable behaviour.
 *
 * To retrieve the real and impaginary parts of the complex number z use
 * z.real and z.imag
 *
 * Note that most methods can be chained e.g.
 * z.tan().sqrt();
 *
 * This will calulate and return the square root of the tangent of z, in
 * mathemaics we are evaluating sqrt(tan(z)) leaving z unchanged.
 *
 * In some situations floating point errors can be significant so testing
 * for equality or to see if the number represents a real value can be
 * problematic. By the default the maximum permitted difference is 10^-8
 * but in some situations this maybe too restrictive and reject values you
 * wish to consider equal. The Complex.setEpsilon() method can be used to
 * change the global EPSILON value. Alternatively some methods accept an
 * epsilon parameter value to be used in the test leaving the global value
 * unchanged.
 *
 * Last updated: 17 Jul 2023
 *
 * @author Peter Lager (2023)
 *
 */
class Complex {
    constructor(re = 0, im = 0) {
        this._re = re;
        this._im = im;
    }
    /**
     * Return a complex number given values for the real and imaginary parts.
     * @param re real part
     * @param im imagingary part
     * @returns the complex number
     */
    static fromRI(re = 0, im = 0) {
        return new Complex(re, im);
    }
    /**
     * Return a new complex number that equals the given one number;
     * @param z the complex number to copy
     * @returns duplicate of the given complex number
     */
    static fromZ(z = new Complex()) {
        return new Complex(z._re, z._im);
    }
    /**
     * Return a complex number given polar coordinates
     * @param mod the length of the complex number
     * @param arg the angle subtended by the number
     * @returns the complex number
     */
    static fromPolar(mod, arg) {
        return new Complex(mod * Math.cos(arg), mod * Math.sin(arg));
    }
    /**
     * Return a complex number of a given size but random orientation.
     * @param mod the length of the complex number
     * @returns a complex number of specified length and random orientation
     */
    static fromRandom(mod) {
        let arg = 2 * Math.PI * Math.random();
        return new Complex(mod * Math.cos(arg), mod * Math.sin(arg));
    }
    /**
     * Sets the max difference allowed when testing complex numbers.
     *
     * @param epsilon the maximum difference allowed must be > 0
     */
    static setEpsilon(epsilon) {
        if (Number.isFinite(epsilon) && epsilon > 0)
            Complex.EPSILON = epsilon;
    }
    /**
     * Returns a new array with the elements sorted by their real value
     * and numbers with the same real value are then sorted by their
     * imaginary value.
     *
     * The original array is unchanged.
     *
     * @param z the original array
     * @returns the sorted array
     */
    static sort(z) {
        return [...z].sort((a, b) => a.compareTo(b));
    }
    /**
     * Given an array of complex numbers return a new array containing those
     * that represent real numbers. The original array is unchanged.
     *
     * @param z the original array
     * @param epsilon max diffference allowed (optional)
     * @returns an array containing complex numbers representing real numbers
     */
    static filterRealRoots(z, epsilon = Complex.EPSILON) {
        let nz = [];
        for (let cn of z)
            if (cn.isReal(epsilon))
                nz.push(new Complex(cn.real, 0));
        return nz;
    }
    /**
     * If the original array contains more than 1 element the a new array is
     * returned with duplicates removed leaving just unique vales. The
     * original array is returnred if it has less than 2 elements..
     *
     * In all cases the original array is unchanged.
     *
     * @param z the original array
     * @param epsilon max diffference allowed (optional)
     * @returns an array with duplicates removed
     */
    static removeDuplicates(z, epsilon = Complex.EPSILON) {
        if (z.length <= 1)
            return z; // can't have duplicates so exit
        let zs = [...z].sort((a, b) => a.compareTo(b));
        let nz = [zs[0]];
        for (let i = 1; i < zs.length; i++) {
            if (!zs[i].equals(nz[nz.length - 1], epsilon))
                nz.push(zs[i]);
        }
        return nz;
    }
    get real() { return this._re; }
    get imag() { return this._im; }
    // aka mod or modulus or length of a complex number
    abs() {
        return Math.sqrt(this._re * this._re + this._im * this._im);
    }
    abs_squared() {
        return this._re * this._re + this._im * this._im;
    }
    add(n) {
        if (typeof n === 'object')
            return new Complex(this._re + n._re, this._im + n._im);
        else
            return new Complex(this._re + n, this._im);
    }
    acos() {
        let z = this.squared().sub(1).sqrt().add(this).log()
            .mult(Complex._0_1i_neg);
        return z._re < 0 ? z.negate() : z;
    }
    acosh() {
        let z = this.squared().sub(Complex._1_0i).sqrt().add(this).log();
        return z._re < 0 ? z.negate() : z;
    }
    arg() {
        return Math.atan2(this._im, this._re);
    }
    asin() {
        let t2 = this.squared().sub(Complex._1_0i).negate().sqrt();
        return this.mult(Complex._0_1i).add(t2).log().mult(Complex._0_1i_neg);
    }
    asinh() {
        return this.squared().add(Complex._1_0i).sqrt().add(this).log();
    }
    atan() {
        let _01 = Complex._0_1i;
        return _01.mult(0.5).mult(_01.add(this).div(_01.sub(this)).log());
    }
    atanh() {
        let _10 = Complex._1_0i;
        return _10.add(this).div(_10.sub(this)).log().mult(0.5);
    }
    cbrt() {
        let m = Math.cbrt(this.abs());
        let theta = Math.atan2(this._im, this._re);
        if (theta < 0)
            theta += Math.PI + Math.PI;
        theta /= 3;
        return new Complex(m * Math.cos(theta), m * Math.sin(theta));
    }
    clone() {
        return new Complex(this._re, this._im);
    }
    conj() {
        return new Complex(this._re, -this._im);
    }
    /**
     * This method compares this complex number with another. The main purpose
     * of this is to define an appropriate sort order.
     * Returns
     *  0 if the numbers are the same when using the equals method
     *  -1 if considered less than z
     *  +1 if considered larger than z
     * @param z the complex number to compare with
     * @returns -1, 0 or +1
     */
    compareTo(z) {
        if (this.equals(z))
            return 0;
        else
            return this._re == z._re ? Math.sign(this._im - z._im)
                : Math.sign(this._re - z._re);
    }
    cos() {
        let t = this.mult(Complex._0_1i);
        let z = t.exp().add(t.negate().exp()).mult(0.5);
        return z;
    }
    cosec() {
        return this.sin().pow(-1);
    }
    cosech() {
        return this.sinh().pow(-1);
    }
    cosh() {
        return this.exp().add(this.negate().exp()).mult(0.5);
    }
    cot() {
        return this.cos().div(this.sin());
    }
    coth() {
        return this.cosh().div(this.sinh());
    }
    cubed() {
        let _re = this._re, _im = this.imag;
        let re = _re * _re * _re - 3 * _re * _im * _im;
        let im = 3 * _re * _re * _im - _im * _im * _im;
        return new Complex(re, im);
    }
    div(n) {
        let re, im;
        if (typeof n === 'object') {
            let m2 = n.abs_squared();
            re = (this._re * n._re + this._im * n._im) / m2;
            im = (this._im * n._re - this._re * n._im) / m2;
        }
        else {
            re = this._re / n;
            im = this._im / n;
        }
        return new Complex(re, im);
    }
    equals(z, epsilon = Complex.EPSILON) {
        return Math.abs(this._re - z._re) < epsilon &&
            Math.abs(this._im - z._im) < epsilon;
    }
    exp() {
        let a = Math.exp(this._re);
        let b = Math.cos(this._im);
        let c = Complex._0_1i.mult(Math.sin(this._im)).add(b).mult(a);
        return c;
    }
    isReal(epsilon = Complex.EPSILON) {
        return Math.abs(this._im) <= epsilon;
    }
    isZero(epsilon = Complex.EPSILON) {
        return (Math.abs(this._re) < epsilon) && (Math.abs(this._im) < epsilon);
    }
    log() {
        let re = Math.log(this.abs());
        let im = this._re < 0 && this._im == 0 ? Math.PI : this.arg();
        return new Complex(re, im);
    }
    mod() {
        return Math.sqrt(this._re * this._re + this._im * this._im);
    }
    modSq() {
        return this._re * this._re + this._im * this._im;
    }
    mult(n) {
        let re, im;
        if (typeof n === 'object') {
            re = this._re * n._re - this._im * n._im;
            im = this._re * n._im + this._im * n._re;
        }
        else {
            re = this._re * n;
            im = this._im * n;
        }
        return new Complex(re, im);
    }
    negate() {
        return new Complex(-this._re, -this._im);
    }
    norm() {
        let abs = this.abs();
        return new Complex(this._re / abs, this._im / abs);
    }
    pow(n) {
        return this.log().mult(n).exp();
    }
    roots(n) {
        let roots = [];
        if (Number.isFinite(n) && Number.isInteger(n) && n >= 2) {
            let arg = Math.atan2(this._im, this._re) / n;
            let mod = Math.sqrt(this._re * this._re + this._im * this._im);
            let mod_n = Math.pow(mod, 1 / n);
            let deltaArg = 2 * Math.PI / n;
            for (let r = 0; r < n; r++) {
                roots.push(Complex.fromPolar(mod_n, arg + r * deltaArg));
            }
        }
        return roots;
    }
    sin() {
        let t1 = this.mult(Complex._0_1i).exp().mult(Complex._0_1i_neg);
        let t2 = this.mult(Complex._0_1i_neg).exp().mult(Complex._0_1i_neg);
        return t1.sub(t2).mult(0.5);
    }
    sinh() {
        return this.exp().sub(this.negate().exp()).mult(0.5);
    }
    squared() {
        let re = this._re * this._re - this._im * this._im;
        let im = 2 * this._re * this._im;
        return new Complex(re, im);
    }
    sqrt() {
        let abs = this.abs();
        let re = Math.sqrt(0.5 * (abs + this._re));
        let im = Math.sqrt(0.5 * (abs - this._re));
        if (this._im < 0)
            im *= -1;
        return new Complex(re, im);
    }
    sub(n) {
        if (typeof n === 'object')
            return new Complex(this._re - n._re, this._im - n._im);
        else
            return new Complex(this._re - n, this._im);
    }
    tan() {
        return this.sin().div(this.cos());
    }
    tanh() {
        return this.sinh().div(this.cosh());
    }
    _toDeg(rad) {
        return rad * 180 / Math.PI;
    }
    _toRad(deg) {
        return deg * Math.PI / 180;
    }
    print(precision = 16) {
        console.log(this.$(precision));
        return this;
    }
    $(precision = 16) {
        let sgn = this._im < 0 ? '-' : '+';
        let rep = this._re.toPrecision(precision);
        let imp = Math.abs(this._im).toPrecision(precision);
        let s = `[ ${rep} ${sgn} ${imp}i ]`;
        return s;
    }
    toString() {
        return this.$();
    }
}
Complex.EPSILON = 1E-8;
Complex._1_0i = new Complex(1, 0);
Complex._1_0i_neg = new Complex(-1, 0);
Complex._0_1i = new Complex(0, 1);
Complex._0_1i_neg = new Complex(0, -1);


